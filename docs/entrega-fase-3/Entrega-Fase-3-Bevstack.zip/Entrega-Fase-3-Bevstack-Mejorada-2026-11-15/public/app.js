"use strict";

const PROBLEM_STORAGE_KEY = "bevstack-service-desk-problems-v1";
const STATUSES = ["Nuevo", "En progreso", "En espera", "Escalado", "Resuelto", "Cerrado"];
const ASSIGNEES = ["Account Management", "Customer Service", "Team de Tech", "Directora de Tech", "Proveedor externo"];
const PRIORITY_RULES = {
  Alto: { Alta: "P1", Media: "P1", Baja: "P2" },
  Medio: { Alta: "P1", Media: "P2", Baja: "P3" },
  Bajo: { Alta: "P2", Media: "P3", Baja: "P3" },
};
const PRIORITY_TARGETS = {
  P1: { response: "15 min", resolution: "4 h" },
  P2: { response: "1 h", resolution: "24 h" },
  P3: { response: "4 h", resolution: "3 días hábiles" },
};
const DEMO_TICKET_AGE_MINUTES = new Map([
  ["BV-1048", 35], ["BV-1047", 95], ["BV-1046", 480], ["BV-1045", 1460], ["BV-1044", 2920],
  ["BV-1043", 4335], ["BV-1042", 5800], ["BV-1041", 7210], ["BV-1040", 8650], ["BV-1039", 8690],
]);
const DEFAULT_CATALOG = [
  { id: "new-store", name: "Activación de una nueva tienda", type: "Solicitud", owner: "Account Management", reporter: "Equipo de e-commerce u operaciones de la marca", description: "Incorporar una tienda al servicio y dejarla lista para operar pedidos." },
  { id: "shipping-rules", name: "Cambio en reglas de envío", type: "Solicitud", owner: "Account Management", reporter: "Equipo de e-commerce u operaciones de la marca", description: "Modificar cobertura, tarifas o condiciones de envío de la tienda." },
  { id: "product-config", name: "Actualización de configuración de productos", type: "Solicitud", owner: "Account Management", reporter: "Equipo de e-commerce u operaciones de la marca", description: "Modificar información operativa de productos que afecta su venta o cumplimiento." },
  { id: "operational-config", name: "Cambio de configuración operativa", type: "Solicitud", owner: "Account Management", reporter: "Responsable autorizado de la marca", description: "Ajustar parámetros de la tienda relacionados con su operación diaria." },
  { id: "unprocessed-order", name: "Pedido no procesado", type: "Incidente", owner: "Account Management / Customer Service", reporter: "Operaciones, e-commerce o atención al cliente", description: "Una compra se realizó, pero el pedido no avanzó correctamente hacia su procesamiento." },
  { id: "incorrect-inventory", name: "Inventario incorrecto", type: "Incidente", owner: "Account Management / Customer Service", reporter: "Operaciones, e-commerce o consumidor vía Customer Service", description: "La disponibilidad mostrada no coincide con el inventario esperado para el producto." },
  { id: "payment-without-order", name: "Pago completado sin creación del pedido", type: "Incidente", owner: "Customer Service / Team de Tech", reporter: "Operaciones, e-commerce o consumidor vía Customer Service", description: "El pago se registró, pero la orden correspondiente no aparece correctamente en la operación." },
  { id: "shipping-unavailable", name: "Opción de envío no disponible", type: "Incidente", owner: "Account Management / Customer Service", reporter: "Operaciones, e-commerce o consumidor vía Customer Service", description: "No se puede utilizar una opción de envío que debería estar habilitada para el pedido." },
];
const CATALOG = [...DEFAULT_CATALOG];

function addCatalogCategory(values) {
  const category = Object.fromEntries(["name", "type", "description", "reporter", "owner"].map((key) => [key, String(values[key] || "").trim()]));
  if (!category.name || !category.description || !category.reporter || !category.owner || !["Solicitud", "Incidente"].includes(category.type)) return null;
  const normalizedName = category.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es");
  if (CATALOG.some((item) => item.type === category.type && item.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es") === normalizedName)) return null;
  const baseId = slugify(category.name);
  if (!baseId) return null;
  let id = window.crypto?.randomUUID ? `${baseId}-${window.crypto.randomUUID()}` : baseId;
  let suffix = 2;
  while (CATALOG.some((item) => item.id === id)) id = `${baseId}-${suffix++}`;
  return { id, ...category };
}

const state = {
  view: "dashboard",
  typeFilter: "Todos",
  search: "",
  statusFilter: "Todos los estados",
  priorityFilter: "Todas las prioridades",
  ticketSort: null,
  selectedTicketId: null,
  pendingStatusChange: null,
  tickets: [],
  problemRecords: loadProblemRecords(),
  authSession: null,
  dataLoaded: false,
  dataUserId: null,
  dataLoadingUserId: null,
  dataLoadPromise: null,
};

const appContent = document.querySelector("#app-content");
const pageCrumb = document.querySelector("#page-crumb");

function isoAgo(minutes, from = new Date()) {
  return new Date(from.getTime() - minutes * 60_000).toISOString();
}

function seedTickets() {
  const seed = [
    ["BV-1048", "Pago confirmado, pero el pedido no aparece", "payment-without-order", "Incidente", "Alto", "Alta", "En progreso", "Customer Service", "Portal de marca", "Nébula Spirits", "ORD-78421", 35, "El cliente recibió confirmación del cobro. La orden no aparece en el panel de operaciones y hay tres consumidores afectados.", ["Validamos el cobro y estamos revisando la sincronización de órdenes."]],
    ["BV-1047", "La tienda no procesa pedidos desde esta mañana", "unprocessed-order", "Incidente", "Alto", "Alta", "Escalado", "Team de Tech", "Portal de marca", "Casa Nómada", "", 95, "El flujo de compra falla para varias marcas; el problema empezó después de una actualización del proveedor.", ["AM registró el caso y notificó a Tech. Se abrió seguimiento con el proveedor."]],
    ["BV-1046", "Agregar cobertura de envío para zona 12", "shipping-rules", "Solicitud", "Medio", "Baja", "En progreso", "Account Management", "Portal de marca", "Altura Gin", "", 480, "Solicitamos habilitar la zona 12 a partir del próximo lunes. Las tarifas existentes se mantienen.", ["Recibimos la solicitud. Validaremos la cobertura y la fecha solicitada."]],
    ["BV-1045", "Disponibilidad de producto no coincide con inventario", "incorrect-inventory", "Incidente", "Medio", "Alta", "En espera", "Team de Tech", "Correo de Customer Service", "Nébula Spirits", "ORD-78396", 1460, "El producto aparece disponible en la tienda, pero el retailer reporta inventario agotado.", ["CS confirmó la discrepancia. Estamos esperando la confirmación del feed de inventario."]],
    ["BV-1044", "Preparar una nueva tienda para el lanzamiento", "new-store", "Solicitud", "Bajo", "Baja", "En progreso", "Account Management", "Portal de marca", "Fuego Norte", "", 2920, "Activar la tienda de Fuego Norte antes de la campaña del próximo mes. Credenciales entregadas.", ["Checklist de onboarding iniciado; faltan validar reglas de envío."]],
    ["BV-1043", "No aparece el envío express en el checkout", "shipping-unavailable", "Incidente", "Medio", "Alta", "Nuevo", "Customer Service", "Correo de Customer Service", "Casa Nómada", "ORD-78122", 4335, "Una persona consumidora no puede elegir envío express aunque el destino está dentro de cobertura.", []],
    ["BV-1042", "Actualizar datos operativos de dos productos", "product-config", "Solicitud", "Bajo", "Media", "Cerrado", "Account Management", "Portal de marca", "Altura Gin", "", 5800, "Actualizar descripción y contenido de dos productos antes de publicarlos.", ["Cambios aplicados y confirmados por la marca."]],
    ["BV-1041", "Modificar horario de corte de pedidos", "operational-config", "Solicitud", "Medio", "Baja", "Resuelto", "Account Management", "Portal de marca", "Nébula Spirits", "", 7210, "Cambiar el horario operativo de corte de pedidos de lunes a viernes.", ["Se actualizó la configuración y se verificó con la marca."]],
    ["BV-1040", "Orden cobrada dos veces durante el checkout", "payment-without-order", "Incidente", "Alto", "Media", "En progreso", "Team de Tech", "Correo de Customer Service", "Fuego Norte", "ORD-77804", 8650, "El consumidor reporta dos cargos para una sola compra. CS está coordinando la comunicación.", ["CS solicitó los comprobantes. Tech está revisando los eventos de pago."]],
    ["BV-1039", "Revisar reglas de envío para temporada alta", "shipping-rules", "Solicitud", "Bajo", "Baja", "Cerrado", "Account Management", "Portal de marca", "Casa Nómada", "", 8690, "Ajuste programado de tarifas para temporada alta, sujeto a aprobación de la marca.", ["Solicitud completada dentro del plazo acordado."]],
  ];
  return seed.map((row, index) => ({
    id: row[0], subject: row[1], categoryId: row[2], type: row[3], impact: row[4], urgency: row[5], priority: PRIORITY_RULES[row[4]][row[5]], status: row[6], assignee: row[7], communicationOwner: row[8].includes("Customer Service") ? "Customer Service" : "Account Management", channel: row[8], brand: row[9], orderId: row[10], createdAt: isoAgo(row[11]), updatedAt: isoAgo(Math.max(5, row[11] - 10)), description: row[12], requesterType: row[8].includes("Customer Service") ? "Consumidor" : "Marca", requesterName: row[8].includes("Customer Service") ? "Persona consumidora" : `Equipo de ${row[9]}`, requesterEmail: row[8].includes("Customer Service") ? "consumidor@example.com" : `operaciones@${slugify(row[9])}.com`, comments: row[13].map((content, commentIndex) => ({ id: `${row[0]}-C${commentIndex}`, author: row[8].includes("Customer Service") ? "Customer Service" : "Account Management", body: content, visibility: "Público", createdAt: isoAgo(Math.max(1, row[11] - 8)) })), firstResponseAt: index < 8 ? isoAgo(Math.max(1, row[11] - 8)) : null, resolvedAt: ["Resuelto", "Cerrado"].includes(row[6]) ? isoAgo(Math.max(1, row[11] - 3)) : null, reopenedCount: 0 }));
}

function migrateLegacyTicketStatuses(tickets) {
  let changed = false;
  const migrated = tickets.map((ticket) => {
    if (ticket.status !== "En triage") return ticket;
    changed = true;
    return { ...ticket, status: "En progreso" };
  });
  return changed ? migrated : tickets;
}

function refreshStaleDemoDates(tickets, now = new Date()) {
  const firstVisibleDay = new Date(now);
  firstVisibleDay.setHours(0, 0, 0, 0);
  firstVisibleDay.setDate(firstVisibleDay.getDate() - 6);
  const sampleIsStale = tickets.some((ticket) => {
    if (!DEMO_TICKET_AGE_MINUTES.has(ticket.id)) return false;
    const createdAt = new Date(ticket.createdAt);
    return !Number.isFinite(createdAt.getTime()) || createdAt < firstVisibleDay;
  });
  if (!sampleIsStale) return tickets;
  return tickets.map((ticket) => {
    const ageMinutes = DEMO_TICKET_AGE_MINUTES.get(ticket.id);
    if (ageMinutes === undefined) return ticket;
    const next = {
      ...ticket,
      createdAt: isoAgo(ageMinutes, now),
      updatedAt: isoAgo(Math.max(5, ageMinutes - 10), now),
    };
    if (Array.isArray(ticket.comments)) {
      next.comments = ticket.comments.map((comment) => ({ ...comment, createdAt: isoAgo(Math.max(1, ageMinutes - 8), now) }));
    }
    if (ticket.firstResponseAt) next.firstResponseAt = isoAgo(Math.max(1, ageMinutes - 8), now);
    if (ticket.resolvedAt) next.resolvedAt = isoAgo(Math.max(1, ageMinutes - 3), now);
    return next;
  });
}

function loadProblemRecords() {
  try {
    const saved = localStorage.getItem(PROBLEM_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
    }
  } catch (error) {
    console.warn("No se pudo leer el registro de problemas de la demo.", error);
  }
  return {};
}

function persistProblemRecords() {
  localStorage.setItem(PROBLEM_STORAGE_KEY, JSON.stringify(state.problemRecords));
  updateNavCounts();
}

function applySharedData(data) {
  state.tickets = data.tickets || [];
  CATALOG.splice(DEFAULT_CATALOG.length, CATALOG.length - DEFAULT_CATALOG.length, ...(data.customCategories || []));
  state.dataLoaded = true;
  updateNavCounts();
}

async function saveTicketDraft(current, draft) {
  try {
    const saved = await window.ServiceDeskData.updateTicket(draft, current.updatedAt);
    const index = state.tickets.findIndex((ticket) => ticket.id === current.id);
    if (index >= 0) state.tickets[index] = saved;
    updateNavCounts();
    return saved;
  } catch (error) {
    if (error.name === "TicketConflictError") {
      let refreshed = false;
      try {
        applySharedData(await window.ServiceDeskData.load());
        refreshed = true;
      } catch { /* Keep the current view and explain that the refresh failed. */ }
      const conflictNotice = document.querySelector("#detail-conflict-message");
      if (conflictNotice) {
        conflictNotice.hidden = false;
        conflictNotice.textContent = refreshed
          ? "Este ticket cambió en otra sesión. Se cargaron los datos más recientes; tus campos siguen aquí. Revísalos y guarda otra vez para aplicar tus cambios."
          : "Este ticket cambió en otra sesión y no se pudieron recargar los datos. Tus campos siguen aquí; revisa tu conexión y vuelve a intentarlo antes de cerrar.";
      }
    }
    showToast(error.message || "No se pudo guardar el cambio.", "error");
    return null;
  }
}

function slugify(value) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}

function formatDate(value, options = {}) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("es-GT", { day: "2-digit", month: "short", ...options }).format(new Date(value));
}

function formatDateTime(value) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("es-GT", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function timeAgo(value) {
  const minutes = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 60_000));
  if (minutes < 60) return `hace ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `hace ${hours} h`;
  const days = Math.floor(hours / 24);
  return `hace ${days} d`;
}

function categoryById(id) {
  return CATALOG.find((category) => category.id === id) || CATALOG[0];
}

function calculatePriority(impact, urgency) {
  return PRIORITY_RULES[impact]?.[urgency] || "P3";
}

function statusClass(status) {
  return ({ "Nuevo": "new", "En progreso": "progress", "En espera": "waiting", "Escalado": "escalated", "Resuelto": "resolved", "Cerrado": "closed" })[status] || "";
}

function priorityPill(priority) {
  return `<span class="priority-pill ${priority.toLowerCase()}">${escapeHTML(priority)}</span>`;
}

function statusPill(status) {
  return `<span class="status-pill ${statusClass(status)}">${escapeHTML(status)}</span>`;
}

function typePill(type) {
  const isIncident = type === "Incidente";
  return `<span class="type-pill ${isIncident ? "incident" : "request"}">${isIncident ? "◉" : "◇"} ${escapeHTML(type)}</span>`;
}

function updateNavCounts() {
  const total = document.querySelector("#nav-total");
  const incidents = document.querySelector("#nav-incidents");
  const requests = document.querySelector("#nav-requests");
  const problems = document.querySelector("#nav-problems");
  if (total) total.textContent = state.tickets.filter((ticket) => !["Cerrado", "Resuelto"].includes(ticket.status)).length;
  if (incidents) incidents.textContent = state.tickets.filter((ticket) => ticket.type === "Incidente" && !["Cerrado", "Resuelto"].includes(ticket.status)).length;
  if (requests) requests.textContent = state.tickets.filter((ticket) => ticket.type === "Solicitud" && !["Cerrado", "Resuelto"].includes(ticket.status)).length;
  if (problems) problems.textContent = problemPatterns().filter((pattern) => pattern.isCandidate && pattern.record.status !== "Resuelto").length;
}

function sortedTickets(tickets) {
  const rank = { P1: 1, P2: 2, P3: 3 };
  return [...tickets].sort((a, b) => rank[a.priority] - rank[b.priority] || new Date(a.createdAt) - new Date(b.createdAt));
}

function sortTicketRows(tickets) {
  const sort = state.ticketSort;
  if (!sort) return sortedTickets(tickets);
  const priorityRank = { P1: 1, P2: 2, P3: 3 };
  const statusRank = Object.fromEntries(STATUSES.map((status, index) => [status, index]));
  const direction = sort.direction === "desc" ? -1 : 1;
  const compareValues = (left, right) => {
    if (sort.key === "priority") return ((priorityRank[left.priority] || 0) - (priorityRank[right.priority] || 0)) * direction;
    if (sort.key === "status") return ((statusRank[left.status] ?? STATUSES.length) - (statusRank[right.status] ?? STATUSES.length)) * direction;
    if (sort.key === "assignee") return String(left.assignee || "").localeCompare(String(right.assignee || ""), "es", { sensitivity: "base" }) * direction;
    if (sort.key === "createdAt") return ((Date.parse(left.createdAt) || 0) - (Date.parse(right.createdAt) || 0)) * direction;
    return 0;
  };
  const fallbackRank = { P1: 1, P2: 2, P3: 3 };
  return [...tickets].sort((left, right) => compareValues(left, right) || (fallbackRank[left.priority] || 0) - (fallbackRank[right.priority] || 0) || new Date(left.createdAt) - new Date(right.createdAt));
}

function cycleTicketSort(key) {
  if (!["priority", "status", "assignee", "createdAt"].includes(key)) return state.ticketSort;
  if (state.ticketSort?.key !== key) state.ticketSort = { key, direction: "asc" };
  else if (state.ticketSort.direction === "asc") state.ticketSort = { key, direction: "desc" };
  else state.ticketSort = null;
  return state.ticketSort;
}

function ticketSortHeader(label, key) {
  const active = state.ticketSort?.key === key;
  const direction = active ? state.ticketSort.direction : "normal";
  const icon = direction === "asc" ? "↑" : direction === "desc" ? "↓" : "↕";
  const description = direction === "asc" ? "ascendente; pulsa para descendente" : direction === "desc" ? "descendente; pulsa para orden normal" : "orden normal; pulsa para ascendente";
  return `<th class="sortable-heading"><span>${label}</span><button type="button" class="sort-control ${active ? `active ${direction}` : ""}" data-sort-key="${key}" aria-label="Ordenar por ${label.toLocaleLowerCase("es")}: ${description}" title="${description}">${icon}</button></th>`;
}

function problemPatterns() {
  const grouped = new Map();
  state.tickets.filter((ticket) => ticket.type === "Incidente").forEach((ticket) => {
    if (!grouped.has(ticket.categoryId)) grouped.set(ticket.categoryId, []);
    grouped.get(ticket.categoryId).push(ticket);
  });
  const priorityRank = { P1: 1, P2: 2, P3: 3 };
  return [...grouped.entries()].map(([categoryId, tickets]) => {
    const priorities = { P1: 0, P2: 0, P3: 0 };
    tickets.forEach((ticket) => { priorities[ticket.priority] = (priorities[ticket.priority] || 0) + 1; });
    return {
      categoryId,
      category: categoryById(categoryId),
      tickets: sortedTickets(tickets),
      count: tickets.length,
      p1Count: priorities.P1,
      brands: [...new Set(tickets.map((ticket) => ticket.brand).filter(Boolean))],
      reopenedCount: tickets.reduce((total, ticket) => total + (ticket.reopenedCount || 0), 0),
      priority: priorities.P1 ? "P1" : priorities.P2 ? "P2" : "P3",
      isCandidate: tickets.length >= 2 || priorities.P1 > 0,
      record: state.problemRecords[categoryId] || {},
    };
  }).sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority] || b.brands.length - a.brands.length || b.reopenedCount - a.reopenedCount || b.count - a.count);
}

function ticketCountsByCategory(tickets) {
  return CATALOG.map((category) => {
    const categorized = tickets.filter((ticket) => ticket.categoryId === category.id);
    const incidents = categorized.filter((ticket) => ticket.type === "Incidente").length;
    const requests = categorized.filter((ticket) => ticket.type === "Solicitud").length;
    return { category, incidents, requests, total: incidents + requests };
  }).sort((a, b) => b.total - a.total);
}

function upsertProblemRecord(records, categoryId, values, relatedTicketIds, now) {
  const existing = records[categoryId] || {};
  const nextSequence = Math.max(0, ...Object.values(records).map((record) => Number(record.id?.match(/\d+$/)?.[0] || 0))) + 1;
  return {
    ...records,
    [categoryId]: {
      ...existing,
      id: existing.id || `PRB-${String(nextSequence).padStart(3, "0")}`,
      categoryId,
      status: values.status,
      owner: values.owner,
      cause: (values.cause || "").trim(),
      workaround: (values.workaround || "").trim(),
      permanentAction: (values.permanentAction || "").trim(),
      relatedTicketIds: [...relatedTicketIds],
      updatedAt: now,
    },
  };
}

function commentAuthorFor(ticket, visibility) {
  if (visibility === "Interno") return "Agente de soporte";
  return ticket.communicationOwner || (ticket.requesterType === "Consumidor" ? "Customer Service" : "Account Management");
}

function openTickets() {
  return state.tickets.filter((ticket) => !["Resuelto", "Cerrado"].includes(ticket.status));
}

function requesterOrigin(ticket) {
  if (ticket.requesterType === "Consumidor") return "Consumidor";
  if (ticket.requesterType === "Marca") return "Marca";
  return String(ticket.channel || "").toLocaleLowerCase("es").includes("customer service") ? "Consumidor" : "Marca";
}

const SERVICE_TIME_ZONE = "America/New_York";
const SERVICE_HOURS_START = 9;
const SERVICE_HOURS_END = 18;
const serviceTimeFormatter = new Intl.DateTimeFormat("en-US", {
  timeZone: SERVICE_TIME_ZONE, weekday: "short", year: "numeric", month: "2-digit", day: "2-digit",
  hour: "2-digit", minute: "2-digit", hourCycle: "h23",
});

function zonedParts(date) {
  return Object.fromEntries(serviceTimeFormatter.formatToParts(date).map((part) => [part.type, part.value]));
}

function localServiceTimeToUtc(year, month, day, hour) {
  const targetUtc = Date.UTC(year, month - 1, day, hour);
  let candidate = targetUtc;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const local = zonedParts(new Date(candidate));
    const representedUtc = Date.UTC(Number(local.year), Number(local.month) - 1, Number(local.day), Number(local.hour), Number(local.minute));
    candidate += targetUtc - representedUtc;
  }
  return candidate;
}

function businessMinutesBetween(start, end) {
  const startMs = start && typeof start.getTime === "function" ? start.getTime() : new Date(start).getTime();
  const endMs = end && typeof end.getTime === "function" ? end.getTime() : new Date(end).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) return 0;
  const localStart = zonedParts(new Date(startMs));
  const localEnd = zonedParts(new Date(endMs));
  let day = new Date(Date.UTC(Number(localStart.year), Number(localStart.month) - 1, Number(localStart.day)));
  const lastDay = Date.UTC(Number(localEnd.year), Number(localEnd.month) - 1, Number(localEnd.day));
  let minutes = 0;
  while (day.getTime() <= lastDay) {
    const parts = zonedParts(new Date(day.getTime() + 12 * 60 * 60_000));
    if (!(["Sat", "Sun"].includes(parts.weekday))) {
      const open = localServiceTimeToUtc(Number(parts.year), Number(parts.month), Number(parts.day), SERVICE_HOURS_START);
      const close = localServiceTimeToUtc(Number(parts.year), Number(parts.month), Number(parts.day), SERVICE_HOURS_END);
      const overlap = Math.max(0, Math.min(endMs, close) - Math.max(startMs, open));
      minutes += overlap / 60_000;
    }
    day.setUTCDate(day.getUTCDate() + 1);
  }
  return Math.round(minutes);
}

function buildTicketIntakeTrend(tickets, now = new Date()) {
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (6 - index));
    const nextDay = new Date(date);
    nextDay.setDate(date.getDate() + 1);
    const dayTickets = tickets.filter((ticket) => {
      const created = new Date(ticket.createdAt);
      return Number.isFinite(created.getTime()) && created >= date && created < nextDay;
    });
    return {
      date,
      label: new Intl.DateTimeFormat("es", { weekday: "short", timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone }).format(date).replace(".", ""),
      incidents: dayTickets.filter((ticket) => ticket.type === "Incidente").length,
      requests: dayTickets.filter((ticket) => ticket.type === "Solicitud").length,
    };
  });
}

function percentile(values, fraction) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const position = (sorted.length - 1) * fraction;
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  return Math.round(sorted[lower] + (sorted[upper] - sorted[lower]) * (position - lower));
}

function responseMetricsByPriority(tickets) {
  const targets = { P1: 15, P2: 60, P3: 240 };
  return Object.fromEntries(["P1", "P2", "P3"].map((priority) => {
    const responded = tickets.filter((ticket) => ticket.priority === priority && ticket.firstResponseAt && ticket.createdAt)
      .map((ticket) => businessMinutesBetween(ticket.createdAt, ticket.firstResponseAt));
    const withinTarget = responded.filter((minutes) => minutes <= targets[priority]).length;
    return [priority, {
      count: responded.length,
      p50: percentile(responded, 0.5),
      p95: percentile(responded, 0.95),
      targetMinutes: targets[priority],
      withinTarget,
      attainment: responded.length ? Math.round(withinTarget / responded.length * 100) : null,
    }];
  }));
}

function activeTicketAgingBuckets(tickets, now = new Date()) {
  const boundaries = [4 * 60 * 60_000, 24 * 60 * 60_000, 3 * 24 * 60 * 60_000];
  const buckets = ["<4 h", "4–24 h", "1–3 d", ">3 d"].map((label) => ({ label, P1: 0, P2: 0, P3: 0, total: 0 }));
  const nowMs = new Date(now).getTime();
  for (const ticket of tickets) {
    if (["Resuelto", "Cerrado"].includes(ticket.status)) continue;
    const createdMs = new Date(ticket.createdAt).getTime();
    if (!Number.isFinite(createdMs) || createdMs > nowMs) continue;
    const age = nowMs - createdMs;
    const index = boundaries.findIndex((boundary) => age < boundary);
    const bucket = buckets[index < 0 ? buckets.length - 1 : index];
    const priority = ["P1", "P2", "P3"].includes(ticket.priority) ? ticket.priority : "P3";
    bucket[priority] += 1;
    bucket.total += 1;
  }
  return buckets;
}

function viewTitle(view) {
  return ({ dashboard: "Resumen", tickets: "Todos los tickets", incidents: "Cola de incidentes", requests: "Cola de solicitudes", problems: "Análisis de problemas", catalog: "Catálogo del servicio", "service-levels": "Niveles de servicio" })[view] || "Resumen";
}

function render() {
  pageCrumb.textContent = viewTitle(state.view);
  document.querySelectorAll(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === state.view));
  updateNavCounts();
  if (state.view === "dashboard") appContent.innerHTML = renderDashboard();
  else if (["tickets", "incidents", "requests"].includes(state.view)) appContent.innerHTML = renderTicketQueue();
  else if (state.view === "problems") appContent.innerHTML = renderProblems();
  else if (state.view === "catalog") appContent.innerHTML = renderCatalog();
  else if (state.view === "service-levels") appContent.innerHTML = renderServiceLevels();
}

function renderDashboard() {
  const active = openTickets();
  const incidents = active.filter((ticket) => ticket.type === "Incidente");
  const requests = active.filter((ticket) => ticket.type === "Solicitud");
  const open = sortedTickets(active).slice(0, 5);
  const intake = buildTicketIntakeTrend(state.tickets);
  const intakeMax = Math.max(1, ...intake.map((day) => day.incidents + day.requests));
  const categoryCounts = ticketCountsByCategory(state.tickets).filter((item) => item.total > 0);
  const categoryMax = Math.max(1, ...categoryCounts.map((item) => item.total));
  const requesterCounts = {
    Marca: state.tickets.filter((ticket) => requesterOrigin(ticket) === "Marca").length,
    Consumidor: state.tickets.filter((ticket) => requesterOrigin(ticket) === "Consumidor").length,
  };
  const activePriorityCounts = Object.fromEntries(["P1", "P2", "P3"].map((priority) => [priority, active.filter((ticket) => ticket.priority === priority).length]));
  return `
    <div class="page-heading"><div><h1>Buenos días, equipo</h1><p class="page-subtitle">Una vista clara de lo que necesita atención y quién lo está atendiendo.</p></div><button class="primary-button create-ticket-button" data-action="new-ticket"><span>＋</span> Crear ticket</button></div>
    <section class="metric-grid" aria-label="Resumen de tickets">
      ${metricCard("Tickets activos", active.length, "Casos pendientes de atención", "▤", "green")}
      ${metricCard("Incidentes", incidents.length, "Cola de restauración", "◉", "red")}
      ${metricCard("Solicitudes", requests.length, "Cola de cumplimiento", "◇", "amber")}
    </section>
    <section class="dashboard-grid">
      <div class="panel intake-panel"><div class="panel-heading"><div><h2>Entrada diaria de tickets</h2><p>Últimos 7 días · permite detectar aumentos de demanda y separar interrupciones de solicitudes planificadas.</p></div><div class="chart-legend intake-legend"><span><i class="legend-dot intake-incident"></i>Incidente</span><span><i class="legend-dot intake-request"></i>Solicitud</span></div></div>
        <div class="intake-chart" role="img" aria-label="Tickets creados por día durante los últimos siete días, separados entre incidentes y solicitudes">${intake.map((day) => { const total = day.incidents + day.requests; return `<div class="intake-day"><div class="intake-value">${total || ""}</div><div class="intake-column" title="${day.incidents} incidentes, ${day.requests} solicitudes"><i class="intake-incident" style="height:${day.incidents / intakeMax * 100}%"></i><i class="intake-request" style="height:${day.requests / intakeMax * 100}%"></i></div><span>${escapeHTML(day.label)}</span></div>`; }).join("")}</div>
        <p class="chart-decision"><strong>Decisión:</strong> si la entrada crece varios días, revisar capacidad de AM/CS y las categorías que impulsan el aumento en Análisis de problemas.</p>
      </div>
      <div class="panel"><div class="panel-heading"><div><h2>Atención prioritaria</h2><p>Primero los casos de mayor impacto y urgencia.</p></div><button class="panel-action" data-view="tickets">Ver cola →</button></div>
        <div class="priority-list">${open.length ? open.map((ticket) => `<div class="priority-item" data-ticket-id="${escapeHTML(ticket.id)}"> <span class="priority-number ${ticket.priority.toLowerCase()}">${escapeHTML(ticket.priority)}</span><span class="priority-copy"><strong>${escapeHTML(ticket.subject)}</strong><small>${escapeHTML(ticket.brand)} · ${escapeHTML(ticket.assignee)}</small></span><span class="priority-age">${timeAgo(ticket.createdAt)}</span></div>`).join("") : `<div class="empty-state"><strong>Todo al día</strong>No hay casos pendientes de atención.</div>`}</div>
      </div>
    </section>
    <section class="panel category-summary-panel"><div class="panel-heading"><div><h2>Tickets por categoría</h2><p>Volumen de todo el registro · compara incidentes con solicitudes para mostrar qué tipo de trabajo concentra cada tema.</p></div><div class="chart-legend"><span><i class="legend-dot"></i>Incidente</span><span><i class="legend-dot request"></i>Solicitud</span></div></div>
      ${categoryCounts.length ? `<div class="category-chart" role="img" aria-label="Tickets del registro agrupados por categoría y separados entre incidentes y solicitudes">${categoryCounts.map((item) => { const scale = item.total / categoryMax * 100; const incidentWidth = item.total ? item.incidents / item.total * 100 : 0; const requestWidth = item.total ? item.requests / item.total * 100 : 0; return `<div class="chart-row"><span class="chart-label" title="${escapeHTML(item.category.name)}">${escapeHTML(item.category.name)}</span><div class="chart-track"><div class="chart-bar" style="width:${scale}%"><span class="incident-part" style="width:${incidentWidth}%"></span><span class="request-part" style="width:${requestWidth}%"></span></div></div><span class="chart-value">${item.total}</span></div>`; }).join("")}</div>` : `<div class="chart-empty">Aún no hay tickets registrados.</div>`}
      <p class="chart-decision"><strong>Cómo usarlo:</strong> identifica las categorías con más volumen y revisa en Análisis de problemas si se repiten por prioridad, marca o reapertura.</p>
    </section>
    <section class="insight-grid" aria-label="Origen y prioridad de los tickets">
      <div class="panel insight-panel origin-insight"><div class="panel-heading"><div><h2>Origen de los tickets</h2><p>Todos los casos registrados; permite distinguir demanda de marcas y consumidores.</p></div><span class="insight-tag">${state.tickets.length} total</span></div>
        <div class="breakdown-list">${[["Marca", "Marcas", "brand"], ["Consumidor", "Consumidores", "consumer"]].map(([origin, label, tone]) => `<div class="breakdown-row ${tone}"><span>${label}</span><strong>${requesterCounts[origin]}</strong><div class="breakdown-track" aria-hidden="true"><i style="width:${state.tickets.length ? requesterCounts[origin] / state.tickets.length * 100 : 0}%"></i></div></div>`).join("")}</div>
      </div>
      <div class="panel insight-panel priority-insight"><div class="panel-heading"><div><h2>Prioridad de la cola activa</h2><p>El color indica prioridad; la intensidad, cantidad de casos (escala 0–10+).</p></div><span class="insight-tag">${active.length} activos</span></div>
        <div class="priority-heatmap" role="group" aria-label="Mapa de calor de prioridad">${["P1", "P2", "P3"].map((priority) => { const count = activePriorityCounts[priority]; const intensity = Math.min(10, Math.max(0, count)); return `<div class="priority-heat-cell ${intensity >= 7 ? "heat-dark" : ""}" style="background-color:${priorityHeatColor(priority, count)};border-color:${priorityHeatColor(priority, count)}" role="group" aria-label="Prioridad ${priority}: ${count} ${count === 1 ? "ticket activo" : "tickets activos"}"><span class="priority-pill ${priority.toLowerCase()}">${priority}</span><strong>${count}</strong><span>${count === 1 ? "ticket activo" : "tickets activos"}</span></div>`; }).join("")}</div>
        <div class="heatmap-scale"><span>P1 rojo</span><span>P2 ámbar</span><span>P3 verde</span><span>Más intenso = más tickets</span></div>
      </div>
    </section>
    <aside class="dashboard-guidance" aria-label="Modelo de atención"><div><strong>Modelo de atención</strong><p>Las marcas envían tickets; Customer Service registra los casos de consumidores. Account Management y Customer Service comunican avances mientras Tech o el proveedor investiga. Incidente = restaurar; solicitud = cumplir.</p></div><button class="panel-action" data-view="catalog">Ver catálogo →</button></aside>`;
}

function heatLevel(count, max) {
  if (!count || !max) return "heat-0";
  return `heat-${Math.max(1, Math.ceil(count / max * 4))}`;
}

function priorityHeatColor(priority, count) {
  const palette = {
    P1: ["#fff0ef", "#a51e1e"],
    P2: ["#fff4db", "#9a5100"],
    P3: ["#e9f8ef", "#206b41"],
  };
  const [light, dark] = palette[priority] || palette.P3;
  const amount = Math.min(10, Math.max(0, Number(count) || 0)) / 10;
  const channels = (color) => color.match(/[\da-f]{2}/gi).map((channel) => parseInt(channel, 16));
  const start = channels(light);
  const end = channels(dark);
  const result = start.map((channel, index) => Math.round(channel + (end[index] - channel) * amount));
  return `#${result.map((channel) => channel.toString(16).padStart(2, "0")).join("")}`;
}

function selectQueueView(type) {
  const viewByType = { Todos: "tickets", Incidente: "incidents", Solicitud: "requests" };
  if (!viewByType[type]) return;
  state.typeFilter = type;
  state.view = viewByType[type];
  state.search = "";
  state.statusFilter = "Todos los estados";
  state.priorityFilter = "Todas las prioridades";
  render();
}

function metricCard(label, value, foot, icon, color) {
  return `<div class="metric-card"><div class="metric-head"><span>${escapeHTML(label)}</span><span class="metric-icon ${color}">${icon}</span></div><div class="metric-value">${value}</div><div class="metric-foot">${escapeHTML(foot)}</div></div>`;
}

function renderTicketQueue() {
  const selectedType = state.view === "incidents" ? "Incidente" : state.view === "requests" ? "Solicitud" : state.typeFilter;
  const isBoard = ["incidents", "requests"].includes(state.view);
  const base = state.tickets.filter((ticket) => (selectedType === "Todos" || ticket.type === selectedType) && (isBoard || state.statusFilter === "Todos los estados" || ticket.status === state.statusFilter) && (state.priorityFilter === "Todas las prioridades" || ticket.priority === state.priorityFilter));
  const matching = base.filter((ticket) => {
    const needle = state.search.trim().toLocaleLowerCase("es");
    const category = categoryById(ticket.categoryId).name;
    return !needle || [ticket.id, ticket.subject, ticket.brand, ticket.assignee, category, ticket.orderId].some((value) => String(value || "").toLocaleLowerCase("es").includes(needle));
  });
  const filtered = (isBoard ? sortedTickets : sortTicketRows)(matching);
  const pageTitle = state.view === "incidents" ? "Incidentes" : state.view === "requests" ? "Solicitudes de servicio" : "Todos los tickets";
  const subtitle = state.view === "incidents" ? "Restaurar una operación interrumpida o degradada." : state.view === "requests" ? "Cumplir acciones acordadas, repetibles y planificables." : "El registro único del Service Desk, organizado en colas distintas.";
  const counts = { all: state.tickets.length, incidents: state.tickets.filter((ticket) => ticket.type === "Incidente").length, requests: state.tickets.filter((ticket) => ticket.type === "Solicitud").length };
  const statusCounts = {
    active: state.tickets.filter((ticket) => !["Resuelto", "Cerrado"].includes(ticket.status)).length,
    resolved: state.tickets.filter((ticket) => ticket.status === "Resuelto").length,
    closed: state.tickets.filter((ticket) => ticket.status === "Cerrado").length,
  };
  return `<div class="page-heading"><div><h1>${pageTitle}</h1><p class="page-subtitle">${subtitle}</p></div><button class="primary-button create-ticket-button" data-action="new-ticket"><span>＋</span> Crear ticket</button></div>
    ${state.view === "tickets" ? `<section class="status-overview" aria-label="Estado de todos los tickets"><div class="status-overview-heading"><h2>Estado de todos los tickets</h2><span>Conteos globales · no cambian con los filtros</span></div><div class="status-overview-grid"><div class="status-total active"><span>Activos</span><strong>${statusCounts.active}</strong></div><div class="status-total resolved"><span>Resueltos</span><strong>${statusCounts.resolved}</strong></div><div class="status-total closed"><span>Cerrados</span><strong>${statusCounts.closed}</strong></div></div><p class="status-definitions"><span><strong>Resuelto</strong> significa solución aplicada, pendiente de confirmación o cierre.</span><span><strong>Cerrado</strong> significa caso validado y finalizado.</span></p></section>` : ""}
    <section class="ticket-panel"><div class="ticket-panel-head"><div><h2>${isBoard ? "Tablero de trabajo" : "Registro de casos"}</h2><p>${isBoard ? "Arrastra una tarjeta a otra columna para cambiar su estado; confirmarás el movimiento antes de guardarlo." : "Orden inicial por prioridad (P1 a P3). Usa los controles de columna para cambiar el orden."}</p></div><div class="table-tools"><label class="search-box"><span class="sr-only">Buscar tickets</span><input id="ticket-search" type="search" placeholder="Buscar por ticket, marca o pedido" value="${escapeHTML(state.search)}" /></label><select class="filter-select" id="priority-filter" aria-label="Filtrar por prioridad"><option ${state.priorityFilter === "Todas las prioridades" ? "selected" : ""}>Todas las prioridades</option>${["P1", "P2", "P3"].map((priority) => `<option ${state.priorityFilter === priority ? "selected" : ""}>${priority}</option>`).join("")}</select>${isBoard ? "" : `<select class="filter-select" id="status-filter" aria-label="Filtrar por estado"><option ${state.statusFilter === "Todos los estados" ? "selected" : ""}>Todos los estados</option>${STATUSES.map((status) => `<option ${state.statusFilter === status ? "selected" : ""}>${status}</option>`).join("")}</select>`}</div></div>
    <div class="queue-tabs" role="tablist"><button class="queue-tab ${selectedType === "Todos" ? "active" : ""}" data-type-filter="Todos">Todos<span>${counts.all}</span></button><button class="queue-tab ${selectedType === "Incidente" ? "active" : ""}" data-type-filter="Incidente">Incidentes<span>${counts.incidents}</span></button><button class="queue-tab ${selectedType === "Solicitud" ? "active" : ""}" data-type-filter="Solicitud">Solicitudes<span>${counts.requests}</span></button></div>
    ${isBoard ? renderKanbanBoard(filtered) : `<div class="ticket-table-wrap"><table class="ticket-table"><thead><tr><th>Ticket</th><th>Tipo / categoría</th><th>Marca y canal</th>${ticketSortHeader("Prioridad", "priority")}${ticketSortHeader("Estado", "status")}${ticketSortHeader("Responsable", "assignee")}${ticketSortHeader("Creado", "createdAt")}</tr></thead><tbody>${filtered.length ? filtered.map(ticketRow).join("") : `<tr><td colspan="7" class="table-empty">No hay tickets que coincidan con estos filtros.</td></tr>`}</tbody></table></div>`}</section>
    <div class="queue-strip"><div class="queue-chip"><span>Incidentes activos</span><strong>${openTickets().filter((ticket) => ticket.type === "Incidente").length}</strong></div><div class="queue-chip"><span>Solicitudes activas</span><strong>${openTickets().filter((ticket) => ticket.type === "Solicitud").length}</strong></div><div class="queue-chip"><span>Tickets en espera</span><strong>${openTickets().filter((ticket) => ticket.status === "En espera").length}</strong></div></div>`;
}

function ticketRow(ticket) {
  const category = categoryById(ticket.categoryId);
  return `<tr data-ticket-id="${escapeHTML(ticket.id)}"><td><span class="ticket-number">${escapeHTML(ticket.id)}</span><div class="ticket-subject"><strong>${escapeHTML(ticket.subject)}</strong><small>${ticket.orderId ? `Pedido ${escapeHTML(ticket.orderId)}` : `${escapeHTML(ticket.requesterName)} · ${escapeHTML(ticket.requesterType)}`}</small></div></td><td>${typePill(ticket.type)}<div class="ticket-id">${escapeHTML(category.name)}</div></td><td><strong>${escapeHTML(ticket.brand)}</strong><div class="ticket-id">${escapeHTML(ticket.channel)}</div></td><td>${priorityPill(ticket.priority)}</td><td>${statusPill(ticket.status)}</td><td>${escapeHTML(ticket.assignee)}</td><td>${formatDate(ticket.createdAt)}</td></tr>`;
}

function renderKanbanBoard(tickets) {
  return `<div class="kanban-board" aria-label="Tablero de tickets por estado">${STATUSES.map((status) => {
    const columnTickets = sortedTickets(tickets.filter((ticket) => ticket.status === status));
    return `<section class="kanban-column status-${statusClass(status)}" data-status-column="${escapeHTML(status)}" aria-label="Estado ${escapeHTML(status)}"><header class="kanban-column-head"><h3>${escapeHTML(status)}</h3><span>${columnTickets.length}</span></header><div class="kanban-column-body" data-status-drop="${escapeHTML(status)}" aria-label="Soltar tickets en ${escapeHTML(status)}">${columnTickets.length ? columnTickets.map(kanbanCard).join("") : `<p class="kanban-empty">Suelta aquí un ticket</p>`}</div></section>`;
  }).join("")}</div>`;
}

function kanbanCard(ticket) {
  const category = categoryById(ticket.categoryId);
  return `<article class="kanban-card" draggable="true" tabindex="0" data-ticket-card="${escapeHTML(ticket.id)}" data-ticket-id="${escapeHTML(ticket.id)}" aria-label="${escapeHTML(ticket.id)} · ${escapeHTML(ticket.subject)} · ${escapeHTML(ticket.status)}"><div class="kanban-card-meta"><span class="ticket-number">${escapeHTML(ticket.id)}</span>${priorityPill(ticket.priority)}</div><h4>${escapeHTML(ticket.subject)}</h4><p>${escapeHTML(ticket.brand)} · ${escapeHTML(category.name)}</p><div class="kanban-card-footer"><span>${escapeHTML(ticket.assignee || "Sin asignar")}</span><button type="button" class="kanban-change-button" data-action="choose-card-status" data-ticket-id="${escapeHTML(ticket.id)}">Cambiar estado</button></div></article>`;
}

function stageStatusChange(ticketId, nextStatus, updates = {}) {
  const ticket = state.tickets.find((item) => item.id === ticketId);
  if (!ticket || !STATUSES.includes(nextStatus) || ticket.status === nextStatus) return false;
  state.pendingStatusChange = { ticketId, nextStatus, updates };
  return true;
}

function cancelStatusChange() {
  if (!state.pendingStatusChange) return false;
  state.pendingStatusChange = null;
  return true;
}

async function confirmStatusChange() {
  const pending = state.pendingStatusChange;
  if (!pending) return null;
  const ticket = state.tickets.find((item) => item.id === pending.ticketId);
  if (!ticket || !STATUSES.includes(pending.nextStatus) || ticket.status === pending.nextStatus) return null;
  const previousStatus = ticket.status;
  const previousPriority = ticket.priority;
  const now = new Date().toISOString();
  const draft = { ...ticket, ...(pending.updates || {}) };
  draft.status = pending.nextStatus;
  if (["Resuelto", "Cerrado"].includes(pending.nextStatus) && !draft.resolvedAt) draft.resolvedAt = now;
  if (["Resuelto", "Cerrado"].includes(previousStatus) && !["Resuelto", "Cerrado"].includes(pending.nextStatus)) {
    draft.resolvedAt = null;
    draft.reopenedCount = (draft.reopenedCount || 0) + 1;
  }
  draft.updatedAt = now;
  if (draft.priority !== previousPriority) draft.priorityChangedAt = now;
  const saved = await saveTicketDraft(ticket, draft);
  if (saved) state.pendingStatusChange = null;
  return saved;
}

function statusChangeDialogMarkup(ticketId, nextStatus) {
  const ticket = state.tickets.find((item) => item.id === ticketId);
  if (!ticket || !STATUSES.includes(nextStatus) || ticket.status === nextStatus) return "";
  const body = `<p class="status-confirm-copy">¿Confirmas mover <strong>${escapeHTML(ticket.id)} · ${escapeHTML(ticket.subject)}</strong> de <span class="status-pill ${statusClass(ticket.status)}">${escapeHTML(ticket.status)}</span> a <span class="status-pill ${statusClass(nextStatus)}">${escapeHTML(nextStatus)}</span>?</p><p class="form-help">El cambio se guardará en el Service Desk.</p>`;
  return dialogMarkup("Confirmar cambio de estado", "Verifica el movimiento antes de guardarlo.", body, `<button class="secondary-button" data-action="cancel-status-change">Cancelar</button><button class="primary-button" data-action="confirm-status-change">Confirmar cambio</button>`);
}

function renderCatalog() {
  const requests = CATALOG.filter((item) => item.type === "Solicitud");
  const incidents = CATALOG.filter((item) => item.type === "Incidente");
  return `<div class="page-heading"><div><h1>Catálogo del servicio</h1><p class="page-subtitle">Qué puede solicitar o reportar cada usuario y quién lo atiende.</p></div><button class="primary-button create-ticket-button" data-action="new-category"><span>＋</span> Agregar categoría</button></div>
    <div class="section-note"><strong>Un punto de contacto:</strong> las marcas usan Account Management; Customer Service registra los casos de consumidores recibidos por los canales de la marca. Toda la demanda termina en el mismo registro.</div>
    <div class="panel-heading"><div><h2>Solicitudes de servicio <span class="nav-count">${requests.length}</span></h2><p>Acciones previstas: el objetivo es cumplirlas dentro del plazo acordado.</p></div></div><div class="catalog-grid">${requests.map(catalogCard).join("")}</div>
    <div class="panel-heading" style="margin-top:25px"><div><h2>Incidentes <span class="nav-count">${incidents.length}</span></h2><p>Fallas no planificadas: el objetivo es restaurar el servicio afectado.</p></div></div><div class="catalog-grid">${incidents.map(catalogCard).join("")}</div>`;
}

function catalogCard(item) {
  return `<article class="catalog-card"><div class="catalog-card-top"><span class="type-label ${item.type === "Incidente" ? "incident" : "request"}">${item.type}</span><span class="ticket-id">${item.type === "Incidente" ? "Restaurar" : "Cumplir"}</span></div><h3>${escapeHTML(item.name)}</h3><p>${escapeHTML(item.description)}</p><div class="catalog-owner"><span>Reporta:</span><strong>${escapeHTML(item.reporter)}</strong></div><div class="catalog-owner" style="margin-top:7px;padding-top:0;border-top:0"><span>Primera atención:</span><strong>${escapeHTML(item.owner)}</strong></div></article>`;
}

function renderProblems() {
  const patterns = problemPatterns();
  const candidates = patterns.filter((pattern) => pattern.isCandidate);
  const totalIncidents = patterns.reduce((total, pattern) => total + pattern.count, 0);
  const ticketCategoryCounts = ticketCountsByCategory(state.tickets);
  const ticketCategoryMax = Math.max(1, ...ticketCategoryCounts.map((item) => item.total));
  return `<div class="page-heading"><div><h1>Análisis de problemas</h1><p class="page-subtitle">Agrupa incidentes por categoría, enlaza sus casos y documenta la investigación de recurrencias.</p></div><button class="primary-button" data-view="incidents">Abrir cola de incidentes →</button></div>
    <div class="section-note"><strong>Lectura responsable:</strong> el patrón por categoría es una señal para investigar, no una causa raíz confirmada. Orden provisional: prioridad, marcas afectadas, reaperturas y volumen. Un patrón con dos o más incidentes o algún P1 se marca para investigación; ambos criterios deben validarse con Bevstack.</div>
    <section class="metric-grid" aria-label="Resumen del análisis de problemas">
      ${metricCard("Incidentes analizados", totalIncidents, "Todos los incidentes registrados", "◉", "red")}
      ${metricCard("Patrones candidatos", candidates.length, "Dos o más casos o algún P1", "⌕", "blue")}
      ${metricCard("Marcas afectadas", new Set(patterns.flatMap((pattern) => pattern.brands)).size, "Marcas distintas en los casos", "▤", "green")}
      ${metricCard("Casos reabiertos", patterns.reduce((total, pattern) => total + pattern.reopenedCount, 0), "Señal para revisar recurrencia", "↻", "amber")}
    </section>
    <section class="dashboard-grid problem-analysis-grid">
      <div class="panel"><div class="panel-heading"><div><h2>Tickets ingresados por categoría</h2><p>Conteo de todo el registro; los segmentos separan incidentes y solicitudes.</p></div><div class="chart-legend"><span><i class="legend-dot"></i>Incidente</span><span><i class="legend-dot request"></i>Solicitud</span></div></div>
        ${ticketCategoryCounts.some((item) => item.total) ? `<div class="category-chart" role="img" aria-label="Gráfico de todos los tickets agrupados por categoría">${ticketCategoryCounts.map((item) => { const scale = item.total / ticketCategoryMax * 100; const incidentWidth = item.total ? item.incidents / item.total * 100 : 0; const requestWidth = item.total ? item.requests / item.total * 100 : 0; return `<div class="chart-row"><span class="chart-label" title="${escapeHTML(item.category.name)}">${escapeHTML(item.category.name)}</span><div class="chart-track"><div class="chart-bar" style="width:${scale}%"><span class="incident-part" style="width:${incidentWidth}%"></span><span class="request-part" style="width:${requestWidth}%"></span></div></div><span class="chart-value">${item.total}</span></div>`; }).join("")}</div>` : `<div class="empty-state"><strong>Aún no hay tickets</strong>Al registrarlos, aquí verás el volumen por categoría y tipo.</div>`}
      </div>
      <div class="panel problem-method"><div class="panel-heading"><div><h2>De incidente a problema</h2><p>Investigar causa y evitar que los síntomas vuelvan a ocurrir.</p></div></div><ol><li>Detectar recurrencia, prioridad, marcas y reaperturas.</li><li>Relacionar los tickets del patrón.</li><li>Investigar la causa con Tech y registrar workaround.</li><li>Documentar solución permanente y comprobar que no se repita.</li></ol><div class="problem-cause-note"><strong>Sin evidencia, no se atribuye causa:</strong> cada análisis inicia pendiente de investigación.</div></div>
    </section>
    <section class="ticket-panel problem-register"><div class="ticket-panel-head"><div><h2>Mapa de patrones y seguimiento</h2><p>Tickets vinculados, prioridad, marcas, reaperturas y estado de investigación.</p></div></div>
      ${patterns.length ? `<div class="ticket-table-wrap"><table class="ticket-table"><thead><tr><th>Patrón / categoría</th><th>Tickets relacionados</th><th>Prioridad / marcas</th><th>Casos / reaperturas</th><th>Investigación</th><th>Responsable</th><th></th></tr></thead><tbody>${patterns.map((pattern) => {
    const record = pattern.record;
    const related = pattern.tickets.map((ticket) => `<button class="problem-ticket-link" data-ticket-id="${escapeHTML(ticket.id)}">${escapeHTML(ticket.id)}</button>`).join(" ");
    return `<tr><td><strong>${escapeHTML(pattern.category.name)}</strong><div class="ticket-id">${pattern.isCandidate ? "Candidato a problema" : "Incidente observado"}</div></td><td>${related || "—"}</td><td>${priorityPill(pattern.priority)}<div class="ticket-id">${pattern.brands.length} marca(s) · ${pattern.p1Count} P1</div></td><td><strong>${pattern.count}</strong><div class="ticket-id">${pattern.reopenedCount} reapertura(s)</div></td><td><span class="status-pill ${record.status ? statusClass(record.status) : "waiting"}">${escapeHTML(record.status || "Pendiente de investigación")}</span><div class="ticket-id">Causa: ${escapeHTML(record.cause || "por determinar")}</div></td><td>${escapeHTML(record.owner || "Team de Tech")}</td><td><button class="quiet-button" data-action="analyze-problem" data-category-id="${escapeHTML(pattern.categoryId)}">${record.status ? "Actualizar análisis" : "Documentar"}</button></td></tr>`;
  }).join("")}</tbody></table></div>` : `<div class="empty-state"><strong>Sin patrones para mapear</strong>El análisis se actualizará cuando se registren incidentes.</div>`}
    </section>`;
}

function renderServiceLevels() {
  const priorityRows = ["P1", "P2", "P3"].map((priority) => `<tr><td><strong>${priority}</strong></td><td>${PRIORITY_TARGETS[priority].response}</td><td>${PRIORITY_TARGETS[priority].resolution}</td><td>${priority === "P3" ? "3 días hábiles" : PRIORITY_TARGETS[priority].resolution}</td></tr>`).join("");
  const responded = state.tickets.filter((ticket) => ticket.firstResponseAt).length;
  const terminal = state.tickets.filter((ticket) => ["Resuelto", "Cerrado"].includes(ticket.status));
  const resolvedWithTime = terminal.filter((ticket) => ticket.resolvedAt).length;
  const reopened = terminal.filter((ticket) => Number(ticket.reopenedCount || 0) > 0).length;
  return `<div class="page-heading"><div><h1>Niveles de servicio</h1><p class="page-subtitle">Metas visibles para las marcas y acuerdos internos que permiten cumplirlas.</p></div></div>
    <div class="section-note"><strong>Distinción del modelo operativo:</strong> la Fase 1 fija metas mensuales de desempeño de 95%. Como no define una consecuencia contractual por incumplimiento, aquí se presentan como <strong>SLO internos</strong>. Un SLA formal con la marca requiere acordar la consecuencia.</div>
    <section class="levels-grid"><div class="panel levels-targets"><div class="panel-heading"><div><h2>Metas por prioridad</h2><p>Ventana de medición del SLO: mensual, según prioridad.</p></div><span class="section-marker blue">SLO</span></div><div class="sla-table-wrap" role="region" aria-label="Metas por prioridad, desplazable horizontalmente"><table class="sla-table"><thead><tr><th>Prioridad</th><th>Primera respuesta</th><th>Restaurar incidente</th><th>Cumplir solicitud</th></tr></thead><tbody>${priorityRows}</tbody></table></div><div class="service-window"><span class="service-window-icon">◷</span><div><strong>Horario de atención</strong><br/>Lunes a viernes, 9:00 a. m. a 6:00 p. m., hora del Este de EE. UU. Fuera de horario se escala la afectación crítica.</div></div><div class="info-banner"><strong>Cómo leer la meta:</strong> cada SLO se evalúa mensualmente; el objetivo es cumplir al menos 95% de los casos elegibles. Incidente mide restauración del servicio; solicitud mide entrega de la acción solicitada.</div></div>
      <div class="panel levels-chain"><div class="panel-heading"><div><h2>Acuerdos internos (OLA)</h2><p>Los tiempos internos sostienen la meta de cara a la marca.</p></div><span class="section-marker cyan">OLA</span></div><div class="sla-chain"><div class="chain-row"><strong>Account Management / Customer Service</strong><span class="chain-arrow">→</span><span>Registrar y asignar<br/><b>P1 10 min · P2 30 min · P3 1 h</b></span></div><div class="chain-row"><strong>Team de Tech</strong><span class="chain-arrow">→</span><span>Iniciar revisión<br/><b>P1 15 min · P2 1 h · P3 4 h</b></span></div><div class="chain-row"><strong>Directora de Tech</strong><span class="chain-arrow">→</span><span>Revisar escalación crítica<br/><b>Máximo 30 min</b></span></div><div class="chain-row"><strong>Developer externo</strong><span class="chain-arrow">→</span><span>Confirmar recepción<br/><b>Máximo 2 h cuando aplique</b></span></div></div><div class="info-banner"><strong>Dependencia externa:</strong> validar el compromiso del proveedor (UC) y que el recorrido completo deje margen para cumplir la meta al usuario.</div></div>
    </section>
    <section class="panel escalation-panel"><div class="panel-heading"><div><h2>Escalamiento y comunicación</h2><p>Escalar cambia quién resuelve; no quién mantiene informado al usuario.</p></div></div><div class="escalation-grid"><div class="escalation-route functional"><span>Funcional · conocimiento técnico</span><strong>N1 AM/CS <i>→</i> N2 Tech <i>→</i> N3 proveedor</strong></div><div class="escalation-route hierarchical"><span>Jerárquico · autoridad o recursos</span><strong>Tech Lead <i>→</i> dirección / CEO</strong></div><div class="escalation-route communication"><span>Comunicación visible al usuario</span><strong>AM para marcas · CS para consumidores</strong></div></div></section>
    <section class="improvement-section"><div class="panel-heading"><div><h2>Indicadores de mejora</h2><p>Qué se mide, cómo se calcula, qué meta aplica y qué información falta para tomar decisiones.</p></div><span class="section-marker navy">SLI / SLO</span></div>
      <div class="indicator-grid">
        <article class="indicator-card response-indicator"><div class="indicator-top"><span class="indicator-kind">SLO · experiencia</span><span class="indicator-target">Meta ≥ 95%</span></div><h3>Primera respuesta dentro del objetivo</h3><p>Casos dentro del objetivo ÷ casos con respuesta registrada. Segmentar por prioridad, marca y origen.</p><div class="indicator-evidence"><strong>Datos cargados</strong><span>${responded} de ${state.tickets.length} tickets tienen primera respuesta registrada.</span></div></article>
        <article class="indicator-card resolution-indicator"><div class="indicator-top"><span class="indicator-kind">SLO · resultado</span><span class="indicator-target">Meta ≥ 95%</span></div><h3>Restauración o cumplimiento en plazo</h3><p>Casos resueltos dentro del objetivo ÷ casos resueltos elegibles. Incidentes restaurados; solicitudes cumplidas.</p><div class="indicator-evidence"><strong>Datos cargados</strong><span>${resolvedWithTime} de ${terminal.length} tickets resueltos/cerrados tienen fecha de resolución.</span></div></article>
        <article class="indicator-card assignment-indicator"><div class="indicator-top"><span class="indicator-kind">SLO interno</span><span class="indicator-target">Meta ≥ 95%</span></div><h3>Registro, prioridad y asignación</h3><p>Casos registrados, priorizados y asignados dentro del tiempo de triage ÷ casos recibidos; revisión mensual.</p><div class="indicator-evidence unavailable"><strong>No medible aún</strong><span>Falta registrar cuándo se completó el triage y la asignación.</span></div></article>
        <article class="indicator-card first-contact-indicator"><div class="indicator-top"><span class="indicator-kind">Eficacia · sin meta acordada</span><span class="indicator-target neutral">Definir umbral</span></div><h3>Resolución en primer contacto</h3><p>Casos resueltos sin transferencia ni contacto adicional ÷ casos atendidos. Ayuda a detectar fricción en N1.</p><div class="indicator-evidence unavailable"><strong>No medible aún</strong><span>Registrar resolución en primer contacto y número de contactos.</span></div></article>
        <article class="indicator-card reopen-indicator"><div class="indicator-top"><span class="indicator-kind">Recurrencia · sin meta acordada</span><span class="indicator-target neutral">Definir umbral</span></div><h3>Reaperturas</h3><p>Casos reabiertos ÷ casos resueltos/cerrados. Revisar tendencia por marca y categoría como señal de solución incompleta.</p><div class="indicator-evidence"><strong>Datos cargados</strong><span>${reopened} de ${terminal.length} tickets resueltos/cerrados tienen al menos una reapertura.</span></div></article>
        <article class="indicator-card satisfaction-indicator"><div class="indicator-top"><span class="indicator-kind">Experiencia · sin meta acordada</span><span class="indicator-target neutral">Definir encuesta</span></div><h3>Satisfacción</h3><p>Promedio de encuesta posterior al cierre y tasa de respuesta; comparar con reaperturas y cumplimiento del SLO.</p><div class="indicator-evidence unavailable"><strong>No medible aún</strong><span>Definir escala, momento de encuesta y campo de respuesta.</span></div></article>
      </div>
      <div class="measurement-note"><strong>Lectura de los indicadores:</strong> la cobertura y las reaperturas se calculan sobre los tickets cargados en el Service Desk. Para medir cumplimiento real del SLO hacen falta marcas de tiempo confiables, horario hábil acordado y plazos objetivo registrados por prioridad.</div>
    </section>`;
}

function showToast(message, type = "success") {
  const region = document.querySelector("#toast-region");
  const toast = document.createElement("div");
  toast.className = `toast ${type === "error" ? "error" : ""}`;
  toast.textContent = message;
  region.append(toast);
  setTimeout(() => toast.remove(), 3300);
}

function dialogMarkup(title, subtitle, body, footer = "", wide = false, modalClass = "") {
  return `<div class="modal-backdrop" data-action="backdrop-close"><section class="modal ${wide ? "wide" : ""} ${modalClass}" role="dialog" aria-modal="true" aria-label="${escapeHTML(title)}"><header class="modal-header"><div><h2>${escapeHTML(title)}</h2><p>${escapeHTML(subtitle)}</p></div><button class="modal-close" data-action="close-modal" aria-label="Cerrar">×</button></header><div class="modal-body">${body}</div>${footer ? `<footer class="modal-footer">${footer}</footer>` : ""}</section></div>`;
}

function openCreateDialog() {
  const modalHost = document.createElement("div");
  modalHost.id = "modal-host";
  modalHost.innerHTML = dialogMarkup("Crear ticket", "Registra la solicitud de una marca o el caso que Customer Service recibe de un consumidor.", createFormMarkup(), `<button class="secondary-button" data-action="close-modal">Cancelar</button><button class="primary-button" type="submit" form="ticket-form">Crear ticket</button>`, true, "create-ticket-modal");
  document.body.append(modalHost);
  const form = modalHost.querySelector("#ticket-form");
  bindCreateForm(form);
  form.querySelector("#ticket-type").dispatchEvent(new Event("change"));
  form.querySelector("#ticket-impact").dispatchEvent(new Event("change"));
  form.querySelector("#ticket-subject").focus();
}

function categoryFormMarkup() {
  return `<form id="category-form" class="create-ticket-form"><p class="form-instructions">Define la categoría que el equipo verá en el catálogo y podrá asignar a nuevos tickets.</p>
    <fieldset class="form-section"><legend>Información de la categoría</legend><div class="form-grid">
      <div class="field"><label for="category-type">Tipo de atención <span class="required">*</span></label><select id="category-type" name="type" required><option value="Solicitud">Solicitud</option><option value="Incidente">Incidente</option></select><small>Solicitud = cumplir una acción. Incidente = restaurar el servicio.</small></div>
      <div class="field"><label for="category-name">Nombre de categoría <span class="required">*</span></label><input id="category-name" name="name" required maxlength="80" placeholder="Ej. Integración de inventario" /></div>
      <div class="field full"><label for="category-description">Descripción y alcance <span class="required">*</span></label><textarea id="category-description" name="description" required maxlength="300" placeholder="¿Qué necesidad o falla cubre esta categoría?"></textarea></div>
      <div class="field"><label for="category-reporter">Quién puede reportarla <span class="required">*</span></label><input id="category-reporter" name="reporter" required maxlength="120" placeholder="Ej. Operaciones de la marca" /></div>
      <div class="field"><label for="category-owner">Primera atención <span class="required">*</span></label><input id="category-owner" name="owner" required maxlength="100" placeholder="Ej. Account Management" /></div>
      <p id="category-error" class="form-error full" role="alert" hidden></p>
    </div></fieldset></form>`;
}

function openCategoryDialog() {
  const modalHost = document.createElement("div");
  modalHost.id = "modal-host";
  modalHost.innerHTML = dialogMarkup("Agregar categoría", "Los campos obligatorios se mostrarán también al crear tickets.", categoryFormMarkup(), `<button class="secondary-button" data-action="close-modal">Cancelar</button><button class="primary-button" type="submit" form="category-form">Guardar categoría</button>`, true, "category-editor-modal");
  document.body.append(modalHost);
  const form = modalHost.querySelector("#category-form");
  form.querySelector("#category-name").focus();
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(form).entries());
    const category = addCatalogCategory(values);
    if (!category) {
      const error = form.querySelector("#category-error");
      error.hidden = false;
      error.textContent = "Completa todos los campos y verifica que no exista otra categoría con el mismo nombre y tipo.";
      return;
    }
    const submit = modalHost.querySelector('button[form="category-form"]');
    if (submit) submit.disabled = true;
    try {
      const saved = await window.ServiceDeskData.createCategory(category);
      CATALOG.push(saved);
    } catch (error) {
      if (submit) submit.disabled = false;
      const fieldError = form.querySelector("#category-error");
      fieldError.hidden = false;
      fieldError.textContent = error.code === "23505" ? "Ya existe una categoría con ese nombre y tipo." : error.message || "No se pudo guardar la categoría. Revisa la conexión e inténtalo de nuevo.";
      return;
    }
    closeModal();
    render();
    showToast(`Categoría “${category.name}” agregada al catálogo.`);
  });
}

function openProblemDialog(categoryId) {
  const category = categoryById(categoryId);
  const existing = state.problemRecords[categoryId] || {};
  const modalHost = document.createElement("div");
  modalHost.id = "modal-host";
  const body = `<form id="problem-form"><div class="form-grid"><div class="field"><label for="problem-status">Estado del análisis</label><select id="problem-status" name="status">${["Investigando", "Error conocido", "Mitigado", "Resuelto"].map((status) => `<option ${existing.status === status ? "selected" : ""}>${status}</option>`).join("")}</select></div><div class="field"><label for="problem-owner">Responsable de investigación</label><select id="problem-owner" name="owner">${["Team de Tech", "Account Management", "Customer Service", "Directora de Tech", "Proveedor externo"].map((owner) => `<option ${existing.owner === owner ? "selected" : ""}>${owner}</option>`).join("")}</select></div><div class="field full"><label>Patrón</label><input value="${escapeHTML(category.name)}" disabled /></div><div class="field full"><label for="problem-cause">Causa raíz o hipótesis (indicar si está por validar)</label><textarea id="problem-cause" name="cause" placeholder="Pendiente de investigación técnica">${escapeHTML(existing.cause || "")}</textarea></div><div class="field full"><label for="problem-workaround">Workaround para el Service Desk</label><textarea id="problem-workaround" name="workaround" placeholder="Qué puede hacer AM/CS mientras se investiga">${escapeHTML(existing.workaround || "")}</textarea></div><div class="field full"><label for="problem-action">Acción o solución permanente</label><textarea id="problem-action" name="permanentAction" placeholder="Acción correctiva, responsable y validación">${escapeHTML(existing.permanentAction || "")}</textarea></div></div></form>`;
  const relatedCount = problemPatterns().find((pattern) => pattern.categoryId === categoryId)?.count || 0;
  modalHost.innerHTML = dialogMarkup(existing.id ? `Actualizar ${existing.id}` : "Documentar análisis de problema", `${category.name} · ${relatedCount} incidente(s) relacionados`, body, `<button class="secondary-button" data-action="close-modal">Cancelar</button><button class="primary-button" type="submit" form="problem-form">Guardar análisis</button>`, true);
  document.body.append(modalHost);
  modalHost.querySelector("#problem-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    const relatedTicketIds = problemPatterns().find((pattern) => pattern.categoryId === categoryId)?.tickets.map((ticket) => ticket.id) || [];
    state.problemRecords = upsertProblemRecord(state.problemRecords, categoryId, values, relatedTicketIds, new Date().toISOString());
    persistProblemRecords();
    closeModal();
    render();
    showToast("Análisis de problema guardado.");
  });
}

function createFormMarkup() {
  return `<form id="ticket-form" class="create-ticket-form"><p class="form-instructions">Completa los campos marcados con <span class="required">*</span>. El formulario calcula la prioridad según impacto y urgencia.</p>
    <fieldset class="form-section"><legend>1. Clasifica el caso</legend><div class="form-grid">
      <div class="field"><label for="ticket-type">Tipo de demanda <span class="required">*</span></label><select id="ticket-type" name="type" required><option value="Incidente">Incidente</option><option value="Solicitud">Solicitud</option></select><small>Incidente = restaurar. Solicitud = cumplir una acción prevista.</small></div>
      <div class="field"><label for="ticket-requester-type">Quién reporta <span class="required">*</span></label><select id="ticket-requester-type" name="requesterType" required><option value="Marca">Marca</option><option value="Consumidor">Consumidor</option></select></div>
      <div class="field"><label for="ticket-category">Categoría del catálogo <span class="required">*</span></label><select id="ticket-category" name="categoryId" required></select></div>
      <div class="field"><label for="ticket-channel">Canal de entrada</label><select id="ticket-channel" name="channel"><option value="Portal de marca">Portal de marca</option><option value="Correo de Customer Service">Correo de Customer Service</option></select></div>
    </div></fieldset>
    <fieldset class="form-section"><legend>2. Datos de contacto</legend><div class="form-grid">
      <div class="field"><label for="ticket-brand">Marca <span class="required">*</span></label><input id="ticket-brand" name="brand" required placeholder="Ej. Nébula Spirits" /></div>
      <div class="field"><label for="ticket-requester">Nombre de quien reporta <span class="required">*</span></label><input id="ticket-requester" name="requesterName" required placeholder="Nombre y equipo" /></div>
      <div class="field"><label for="ticket-email">Correo de contacto</label><input id="ticket-email" name="requesterEmail" type="email" placeholder="nombre@marca.com" /></div>
      <div class="field"><label for="ticket-order">Número de pedido</label><input id="ticket-order" name="orderId" placeholder="Opcional; si aplica" /></div>
    </div></fieldset>
    <fieldset class="form-section"><legend>3. Describe lo ocurrido</legend><div class="form-grid">
      <div class="field full"><label for="ticket-subject">Título del caso <span class="required">*</span></label><input id="ticket-subject" name="subject" required maxlength="120" placeholder="Describe brevemente lo ocurrido" /></div>
      <div class="field full"><label for="ticket-description">Descripción <span class="required">*</span></label><textarea id="ticket-description" name="description" required placeholder="¿Qué pasó o qué acción se necesita? Indica el impacto observado."></textarea></div>
    </div></fieldset>
    <fieldset class="form-section"><legend>4. Impacto y urgencia</legend><div class="form-grid">
      <div class="field"><label for="ticket-impact">Impacto <span class="required">*</span></label><select id="ticket-impact" name="impact" required><option value="Alto">Alto</option><option value="Medio">Medio</option><option selected value="Bajo">Bajo</option></select><small>Alto: varias marcas, pagos u órdenes. Medio: una marca con workaround. Bajo: caso individual o función secundaria.</small></div>
      <div class="field"><label for="ticket-urgency">Urgencia <span class="required">*</span></label><select id="ticket-urgency" name="urgency" required><option value="Alta">Alta</option><option value="Media">Media</option><option selected value="Baja">Baja</option></select><small>Alta: ocurre ahora y puede causar pérdidas. Media: resolver hoy. Baja: puede programarse.</small></div>
      <div class="field full"><div class="priority-preview" aria-live="polite"><div><strong>Prioridad calculada</strong><small>Se determina por impacto y urgencia.</small></div><span id="priority-preview-pill" class="priority-pill p3">P3</span></div></div>
      <div id="request-hint" class="field full request-hint" hidden>Esta solicitud entra a su cola separada para cumplir una acción planificada; no desplaza incidentes que requieren restauración.</div>
      <p id="ticket-error" class="form-error full" role="alert" hidden></p>
    </div></fieldset></form>`;
}

function bindCreateForm(form) {
  form.addEventListener("change", (event) => {
    if (event.target.id === "ticket-type") {
      const type = event.target.value;
      const requesterSelect = form.querySelector("#ticket-requester-type");
      const categorySelect = form.querySelector("#ticket-category");
      const items = CATALOG.filter((item) => item.type === type);
      categorySelect.innerHTML = items.map((item) => `<option value="${item.id}">${escapeHTML(item.name)}</option>`).join("");
      requesterSelect.querySelector('option[value="Consumidor"]')?.remove();
      if (type === "Incidente" && !requesterSelect.querySelector('option[value="Consumidor"]')) requesterSelect.insertAdjacentHTML("beforeend", `<option value="Consumidor">Consumidor</option>`);
      if (type === "Solicitud" && requesterSelect.value === "Consumidor") requesterSelect.value = "Marca";
      form.querySelector("#request-hint").hidden = type !== "Solicitud";
      updateAssignmentOptions(form);
    }
    if (event.target.id === "ticket-requester-type") updateAssignmentOptions(form);
    if (["ticket-impact", "ticket-urgency"].includes(event.target.id)) updatePriorityPreview(form);
  });
  form.addEventListener("input", (event) => {
    if (["ticket-impact", "ticket-urgency"].includes(event.target.id)) updatePriorityPreview(form);
  });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(form).entries());
    const category = categoryById(values.categoryId);
    const type = values.type;
    const requesterType = values.requesterType;
    const now = new Date().toISOString();
    const assignee = type === "Solicitud" ? "Account Management" : requesterType === "Consumidor" ? "Customer Service" : "Account Management";
    const ticket = {
      type, categoryId: category.id, subject: values.subject.trim(), description: values.description.trim(),
      requesterType, communicationOwner: requesterType === "Consumidor" ? "Customer Service" : "Account Management", requesterName: values.requesterName.trim(), requesterEmail: values.requesterEmail.trim(),
      brand: values.brand.trim(), orderId: values.orderId.trim(), channel: values.channel,
      impact: values.impact, urgency: values.urgency, priority: calculatePriority(values.impact, values.urgency),
      status: "Nuevo", assignee, createdAt: now, updatedAt: now, comments: [], firstResponseAt: null,
      resolvedAt: null, reopenedCount: 0,
    };
    const submit = document.querySelector('button[form="ticket-form"]');
    if (submit) submit.disabled = true;
    let saved;
    try {
      saved = await window.ServiceDeskData.createTicket(ticket);
    } catch (error) {
      if (submit) submit.disabled = false;
      const fieldError = form.querySelector("#ticket-error");
      if (fieldError) { fieldError.hidden = false; fieldError.textContent = error.message || "No se pudo guardar el ticket. Tus datos siguen en el formulario."; }
      else showToast(error.message || "No se pudo guardar el ticket. Tus datos siguen en el formulario.", "error");
      return;
    }
    state.tickets.unshift(saved);
    closeModal();
    state.view = "tickets";
    state.typeFilter = type;
    state.search = "";
    state.statusFilter = "Todos los estados";
    state.priorityFilter = "Todas las prioridades";
    render();
    showToast(`${saved.id} creado y agregado a la cola de ${type.toLocaleLowerCase("es")}.`);
    openTicket(saved.id);
  });
}

function updateAssignmentOptions(form) {
  const requester = form.querySelector("#ticket-requester-type").value;
  const channel = form.querySelector("#ticket-channel");
  channel.value = requester === "Consumidor" ? "Correo de Customer Service" : "Portal de marca";
}

function updatePriorityPreview(form) {
  const priority = calculatePriority(form.querySelector("#ticket-impact").value, form.querySelector("#ticket-urgency").value);
  const pill = form.querySelector("#priority-preview-pill");
  pill.textContent = priority;
  pill.className = `priority-pill ${priority.toLowerCase()}`;
}

function closeModal() {
  cancelStatusChange();
  document.querySelector("#modal-host")?.remove();
}

function openCardStatusPicker(ticketId) {
  const ticket = state.tickets.find((item) => item.id === ticketId);
  if (!ticket) return;
  const host = document.createElement("div");
  host.id = "modal-host";
  const body = `<form id="card-status-form"><div class="field"><label for="card-next-status">Nuevo estado</label><select id="card-next-status" name="status">${STATUSES.filter((status) => status !== ticket.status).map((status) => `<option>${escapeHTML(status)}</option>`).join("")}</select></div></form>`;
  host.innerHTML = dialogMarkup(`Cambiar estado de ${ticket.id}`, ticket.subject, body, `<button class="secondary-button" data-action="close-modal">Cancelar</button><button class="primary-button" type="submit" form="card-status-form">Continuar</button>`);
  document.body.append(host);
  host.querySelector("#card-status-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const nextStatus = new FormData(event.currentTarget).get("status");
    closeModal();
    openStatusConfirmation(ticketId, nextStatus);
  });
}

function openStatusConfirmation(ticketId, nextStatus, updates = {}) {
  if (!stageStatusChange(ticketId, nextStatus, updates)) return;
  const host = document.createElement("div");
  host.id = "modal-host";
  host.innerHTML = statusChangeDialogMarkup(ticketId, nextStatus);
  document.body.append(host);
}

function openTicket(ticketId) {
  const ticket = state.tickets.find((item) => item.id === ticketId);
  if (!ticket) return;
  state.selectedTicketId = ticketId;
  const host = document.createElement("div");
  host.id = "modal-host";
  host.innerHTML = dialogMarkup(`${ticket.id} · ${ticket.type}`, `${categoryById(ticket.categoryId).name} · Creado ${formatDateTime(ticket.createdAt)}`, ticketDetailMarkup(ticket), "", true);
  document.body.append(host);
  bindDetail(host, ticket.id);
}

function ticketDetailMarkup(ticket) {
  const category = categoryById(ticket.categoryId);
  const comments = ticket.comments || [];
  const formOptions = CATALOG.filter((item) => item.type === ticket.type);
  const body = `<div class="detail-topline">${typePill(ticket.type)}${priorityPill(ticket.priority)}${statusPill(ticket.status)}</div><h3 class="detail-title">${escapeHTML(ticket.subject)}</h3><p class="detail-description">${escapeHTML(ticket.description)}</p>
    <div class="detail-grid"><div class="detail-fact"><span>Marca</span><strong>${escapeHTML(ticket.brand)}</strong></div><div class="detail-fact"><span>Reporta</span><strong>${escapeHTML(ticket.requesterName)} (${escapeHTML(ticket.requesterType)})</strong></div><div class="detail-fact"><span>Canal</span><strong>${escapeHTML(ticket.channel)}</strong></div><div class="detail-fact"><span>Número de pedido</span><strong>${escapeHTML(ticket.orderId || "No aplica")}</strong></div><div class="detail-fact"><span>Impacto / urgencia</span><strong>${escapeHTML(ticket.impact)} / ${escapeHTML(ticket.urgency)}</strong></div><div class="detail-fact"><span>Investigación a cargo de</span><strong>${escapeHTML(ticket.assignee)}</strong></div><div class="detail-fact"><span>Comunicación al usuario</span><strong>${escapeHTML(ticket.communicationOwner || commentAuthorFor(ticket, "Público"))}</strong></div><div class="detail-fact"><span>Primera respuesta</span><strong>${formatDateTime(ticket.firstResponseAt)}</strong></div><div class="detail-fact"><span>Última actualización</span><strong>${formatDateTime(ticket.updatedAt)}</strong></div></div>
    <div class="detail-section-title">Actualizar ticket <span class="ticket-id">Reclasifica, reasigna o cambia el estado</span></div><p id="detail-conflict-message" class="form-error" role="alert" hidden></p><form id="detail-edit-form" class="detail-edit-grid"><div class="field"><label for="edit-category">Categoría</label><select id="edit-category" name="categoryId">${formOptions.map((item) => `<option value="${item.id}" ${item.id === ticket.categoryId ? "selected" : ""}>${escapeHTML(item.name)}</option>`).join("")}</select></div><div class="field"><label for="edit-priority">Prioridad</label><select id="edit-priority" name="priority">${["P1", "P2", "P3"].map((priority) => `<option ${priority === ticket.priority ? "selected" : ""}>${priority}</option>`).join("")}</select></div><div class="field"><label for="edit-status">Estado</label><select id="edit-status" name="status">${STATUSES.map((status) => `<option ${status === ticket.status ? "selected" : ""}>${status}</option>`).join("")}</select></div><div class="field"><label for="edit-assignee">Responsable</label><select id="edit-assignee" name="assignee">${ASSIGNEES.map((assignee) => `<option ${assignee === ticket.assignee ? "selected" : ""}>${assignee}</option>`).join("")}</select></div><div class="field"><label for="edit-impact">Impacto</label><select id="edit-impact" name="impact">${["Alto", "Medio", "Bajo"].map((value) => `<option ${value === ticket.impact ? "selected" : ""}>${value}</option>`).join("")}</select></div><div class="field"><label for="edit-urgency">Urgencia</label><select id="edit-urgency" name="urgency">${["Alta", "Media", "Baja"].map((value) => `<option ${value === ticket.urgency ? "selected" : ""}>${value}</option>`).join("")}</select></div><div class="field full"><button class="secondary-button" type="submit">Guardar cambios</button></div></form>
    <div class="detail-section-title">Comentarios y seguimiento <span class="ticket-id">${comments.length} ${comments.length === 1 ? "actualización" : "actualizaciones"}</span></div><div class="comment-list">${comments.length ? comments.map(commentMarkup).join("") : `<div class="empty-state" style="padding:16px">Aún no hay comentarios. Registra la primera actualización del caso.</div>`}</div><form id="comment-form" class="comment-form"><textarea name="body" required placeholder="Escribe una actualización para dar seguimiento al caso..."></textarea><div class="comment-controls"><select name="visibility" aria-label="Visibilidad del comentario"><option>Público</option><option>Interno</option></select><span class="form-help">Los comentarios internos son para el equipo de soporte.</span></div><button class="primary-button" type="submit">Agregar comentario</button></form>`;
  return body;
}

function commentMarkup(comment) {
  const internal = comment.visibility === "Interno";
  const avatar = internal ? "IN" : comment.author === "Account Management" ? "AM" : comment.author === "Customer Service" ? "CS" : "SD";
  return `<article class="comment ${internal ? "internal" : ""}"><div class="comment-head"><span class="comment-avatar">${avatar}</span><strong>${escapeHTML(comment.author)}</strong><span class="comment-kind">${internal ? "Nota interna" : "Visible para usuario"}</span><small>${formatDateTime(comment.createdAt)}</small></div><p>${escapeHTML(comment.body)}</p></article>`;
}

function bindDetail(host, ticketId) {
  const editForm = host.querySelector("#detail-edit-form");
  editForm.addEventListener("change", (event) => {
    if (["edit-impact", "edit-urgency"].includes(event.target.id)) {
      editForm.querySelector("#edit-priority").value = calculatePriority(editForm.querySelector("#edit-impact").value, editForm.querySelector("#edit-urgency").value);
    }
  });
  editForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const ticket = state.tickets.find((item) => item.id === ticketId);
    const oldStatus = ticket.status;
    const oldPriority = ticket.priority;
    const values = Object.fromEntries(new FormData(editForm).entries());
    const nextStatus = values.status;
    delete values.status;
    if (oldStatus !== nextStatus) {
      closeModal();
      render();
      openStatusConfirmation(ticketId, nextStatus, values);
      return;
    }
    const draft = { ...ticket, ...values, updatedAt: new Date().toISOString() };
    if (draft.priority !== oldPriority) draft.priorityChangedAt = draft.updatedAt;
    const saved = await saveTicketDraft(ticket, draft);
    if (!saved) return;
    closeModal();
    render();
    showToast(`${ticket.id} actualizado.`);
    openTicket(ticketId);
  });
  host.querySelector("#comment-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form).entries());
    const ticket = state.tickets.find((item) => item.id === ticketId);
    const now = new Date().toISOString();
    const draft = { ...ticket, comments: [...(ticket.comments || []), { id: `${ticket.id}-${Date.now()}`, author: commentAuthorFor(ticket, values.visibility), body: values.body.trim(), visibility: values.visibility, createdAt: now }], updatedAt: now };
    if (!draft.firstResponseAt && values.visibility === "Público") draft.firstResponseAt = now;
    const saved = await saveTicketDraft(ticket, draft);
    if (!saved) return;
    closeModal();
    render();
    openTicket(ticketId);
    showToast(values.visibility === "Interno" ? "Nota interna agregada." : "Actualización compartida en el caso.");
  });
}

document.body.addEventListener("click", async (event) => {
  const authAction = event.target.closest("[data-auth-action]")?.dataset.authAction;
  if (authAction === "forgot-password") { renderAuthScreen("reset"); return; }
  if (authAction === "back-to-login") { renderAuthScreen("login"); return; }
  if (authAction === "open-service-desk") { activateServiceDesk(state.authSession); return; }
  if (authAction === "retry-load") { activateServiceDesk(state.authSession); return; }
  if (authAction === "sign-out") { ServiceDeskAuth.signOut().catch((error) => renderAuthScreen("data-error", error.message, true)); return; }
  if (event.target.closest('[data-action="sign-out"]')) {
    ServiceDeskAuth.signOut().catch((error) => showToast(error.message, "error"));
    return;
  }
  const sortControl = event.target.closest("[data-sort-key]");
  if (sortControl) {
    cycleTicketSort(sortControl.dataset.sortKey);
    render();
    return;
  }
  const viewButton = event.target.closest("[data-view]");
  if (viewButton) {
    state.view = viewButton.dataset.view;
    if (["tickets", "incidents", "requests"].includes(state.view)) {
      state.search = "";
      state.statusFilter = "Todos los estados";
      state.priorityFilter = "Todas las prioridades";
      state.typeFilter = state.view === "incidents" ? "Incidente" : state.view === "requests" ? "Solicitud" : "Todos";
    }
    render();
    return;
  }
  const action = event.target.closest("[data-action]")?.dataset.action;
  if (action === "new-ticket") { openCreateDialog(); return; }
  if (action === "new-category") { openCategoryDialog(); return; }
  if (action === "analyze-problem") { openProblemDialog(event.target.closest("[data-category-id]").dataset.categoryId); return; }
  if (action === "choose-card-status") { openCardStatusPicker(event.target.closest("[data-ticket-id]").dataset.ticketId); return; }
  if (action === "cancel-status-change") { cancelStatusChange(); closeModal(); return; }
  if (action === "confirm-status-change") {
    const ticket = await confirmStatusChange();
    if (!ticket) return;
    closeModal();
    render();
    if (ticket) showToast(`${ticket.id} pasó a ${ticket.status}.`);
    return;
  }
  if (action === "close-modal") { closeModal(); return; }
  if (action === "backdrop-close" && event.target.classList.contains("modal-backdrop")) { closeModal(); return; }
  const ticketNode = event.target.closest("[data-ticket-id]");
  if (ticketNode) { openTicket(ticketNode.dataset.ticketId); return; }
  const typeTab = event.target.closest("[data-type-filter]");
  if (typeTab) {
    selectQueueView(typeTab.dataset.typeFilter);
  }
});

function renderAuthScreen(mode = "login", message = "", isError = false) {
  const host = document.querySelector("#auth-shell");
  const shell = document.querySelector(".app-shell");
  if (!host || !shell) return;
  document.querySelector("#modal-host")?.remove();
  shell.hidden = true;
  host.hidden = false;
  const login = mode === "login";
  const reset = mode === "reset";
  const loading = mode === "loading";
  const dataError = mode === "data-error";
  const title = loading ? "Conectando al Service Desk" : dataError ? "No se pudieron cargar los datos" : login ? "Inicia sesión" : reset ? "Recupera tu acceso" : "Actualiza tu contraseña";
  const description = loading ? "Estamos preparando la bandeja compartida del equipo." : dataError ? "La sesión está activa, pero no se pudo leer la información compartida." : login ? "Acceso para el equipo de operación de Bevstack." : reset ? "Te enviaremos un enlace al correo de tu cuenta." : "Define una nueva contraseña para continuar.";
  const form = loading ? `<div class="auth-loading" role="status">Conectando con la base de datos segura...</div>`
    : dataError ? `<div class="auth-form"><button class="primary-button" type="button" data-auth-action="retry-load">Reintentar conexión</button><button class="auth-text-button" type="button" data-auth-action="sign-out">Cerrar sesión</button></div>`
    : login ? `<form id="auth-login-form" class="auth-form"><label>Correo del equipo<input type="email" name="email" autocomplete="username" required /></label><label>Contraseña<input type="password" name="password" autocomplete="current-password" required /></label><button class="primary-button" type="submit">Iniciar sesión</button><button class="auth-text-button" type="button" data-auth-action="forgot-password">Olvidé mi contraseña</button></form>`
    : reset ? `<form id="auth-reset-form" class="auth-form"><label>Correo del equipo<input type="email" name="email" autocomplete="email" required /></label><button class="primary-button" type="submit">Enviar enlace de recuperación</button><button class="auth-text-button" type="button" data-auth-action="back-to-login">Volver al inicio de sesión</button></form>`
      : `<form id="auth-update-form" class="auth-form"><label>Nueva contraseña<input type="password" name="password" autocomplete="new-password" minlength="8" required /></label><label>Confirma la contraseña<input type="password" name="confirmPassword" autocomplete="new-password" minlength="8" required /></label><button class="primary-button" type="submit">Guardar contraseña</button></form>${message && !isError ? `<button class="auth-text-button" type="button" data-auth-action="open-service-desk">Continuar al Service Desk</button>` : ""}`;
  host.innerHTML = `<section class="auth-card" aria-labelledby="auth-title"><div class="auth-brand"><span class="auth-brand-mark">b</span><span><strong>bevstack</strong><small>SERVICE DESK</small></span></div><div class="auth-copy"><h1 id="auth-title">${title}</h1><p>${description}</p></div>${message ? `<p class="auth-message ${isError ? "error" : "success"}" role="status">${escapeHTML(message)}</p>` : ""}${form}${loading || dataError ? "" : `<p class="auth-invite-note">Las cuentas son creadas por la administración del equipo.</p>`}</section>`;
}

async function activateServiceDesk(session) {
  if (!session) { renderAuthScreen("login", "Inicia sesión para continuar.", true); return; }
  const userId = session.user?.id || session.user?.email;
  if (state.dataLoaded && state.dataUserId === userId) {
    state.authSession = session;
    document.querySelector("#auth-shell").hidden = true;
    document.querySelector(".app-shell").hidden = false;
    return;
  }
  if (state.dataLoadPromise && state.dataLoadingUserId === userId) {
    await state.dataLoadPromise;
    return;
  }
  state.authSession = session;
  renderAuthScreen("loading");
  state.dataLoadingUserId = userId;
  const request = window.ServiceDeskData.load();
  state.dataLoadPromise = request;
  try {
    const data = await request;
    if ((state.authSession?.user?.id || state.authSession?.user?.email) !== userId) return;
    applySharedData(data);
    state.dataUserId = userId;
  } catch (error) {
    state.dataLoaded = false;
    renderAuthScreen("data-error", error.message || "Verifica la conexión y vuelve a intentarlo.", true);
    return;
  } finally {
    if (state.dataLoadPromise === request) {
      state.dataLoadPromise = null;
      state.dataLoadingUserId = null;
    }
  }
  const authShell = document.querySelector("#auth-shell");
  const shell = document.querySelector(".app-shell");
  if (authShell) authShell.hidden = true;
  if (shell) shell.hidden = false;
  const email = document.querySelector("#profile-email");
  if (email) email.textContent = session.user?.email || "Cuenta del equipo";
  render();
}

document.body.addEventListener("submit", async (event) => {
  const form = event.target;
  if (!form.matches?.("#auth-login-form, #auth-reset-form, #auth-update-form")) return;
  event.preventDefault();
  const values = Object.fromEntries(new FormData(form).entries());
  const submit = form.querySelector('button[type="submit"]');
  if (submit) submit.disabled = true;
  try {
    if (form.id === "auth-login-form") {
      const session = await ServiceDeskAuth.signIn(values.email, values.password);
      activateServiceDesk(session);
    } else if (form.id === "auth-reset-form") {
      await ServiceDeskAuth.sendPasswordReset(values.email);
      renderAuthScreen("reset", "Si el correo está registrado, recibirás un enlace para restablecer la contraseña.");
    } else {
      if (values.password.length < 8) throw new Error("La contraseña debe tener al menos 8 caracteres.");
      if (values.password !== values.confirmPassword) throw new Error("Las contraseñas no coinciden.");
      await ServiceDeskAuth.updatePassword(values.password);
      renderAuthScreen("update", "Contraseña actualizada. Ya puedes continuar al Service Desk.");
    }
  } catch (error) {
    renderAuthScreen(form.id === "auth-login-form" ? "login" : form.id === "auth-reset-form" ? "reset" : "update", error.message, true);
  }
});

document.body.addEventListener("dragstart", (event) => {
  const card = event.target.closest("[data-ticket-card]");
  if (!card) return;
  if (event.dataTransfer) {
    event.dataTransfer.setData("text/plain", card.dataset.ticketCard);
    event.dataTransfer.effectAllowed = "move";
  }
  card.classList.add("dragging");
});

document.body.addEventListener("dragend", (event) => {
  event.target.closest("[data-ticket-card]")?.classList.remove("dragging");
  document.querySelectorAll(".kanban-column-body.drag-over").forEach((column) => column.classList.remove("drag-over"));
});

document.body.addEventListener("dragover", (event) => {
  const column = event.target.closest("[data-status-drop]");
  if (!column) return;
  event.preventDefault();
  if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
  column.classList.add("drag-over");
});

document.body.addEventListener("dragleave", (event) => {
  const column = event.target.closest("[data-status-drop]");
  if (column && !column.contains(event.relatedTarget)) column.classList.remove("drag-over");
});

document.body.addEventListener("drop", (event) => {
  const column = event.target.closest("[data-status-drop]");
  if (!column) return;
  event.preventDefault();
  column.classList.remove("drag-over");
  const ticketId = event.dataTransfer?.getData("text/plain");
  if (ticketId) openStatusConfirmation(ticketId, column.dataset.statusDrop);
});

document.body.addEventListener("input", (event) => {
  if (event.target.id === "ticket-search") {
    state.search = event.target.value;
    const cursor = event.target.selectionStart;
    if (["incidents", "requests"].includes(state.view)) {
      render();
      const nextSearch = appContent.querySelector("#ticket-search");
      nextSearch?.focus();
      nextSearch?.setSelectionRange(cursor, cursor);
      return;
    }
    const content = appContent.querySelector(".ticket-table-wrap");
    const nextRows = sortTicketRows(state.tickets.filter((ticket) => {
      const selectedType = state.view === "incidents" ? "Incidente" : state.view === "requests" ? "Solicitud" : state.typeFilter;
      return (selectedType === "Todos" || ticket.type === selectedType) && (state.statusFilter === "Todos los estados" || ticket.status === state.statusFilter) && (state.priorityFilter === "Todas las prioridades" || ticket.priority === state.priorityFilter);
    }).filter((ticket) => {
      const needle = state.search.trim().toLocaleLowerCase("es");
      const category = categoryById(ticket.categoryId).name;
      return !needle || [ticket.id, ticket.subject, ticket.brand, ticket.assignee, category, ticket.orderId].some((value) => String(value || "").toLocaleLowerCase("es").includes(needle));
    }));
    if (content) content.querySelector("tbody").innerHTML = nextRows.length ? nextRows.map(ticketRow).join("") : `<tr><td colspan="7" class="table-empty">No hay tickets que coincidan con estos filtros.</td></tr>`;
    event.target.setSelectionRange(cursor, cursor);
  }
});

document.body.addEventListener("change", (event) => {
  if (event.target.id === "priority-filter") {
    state.priorityFilter = event.target.value;
    render();
  }
  if (event.target.id === "status-filter") {
    state.statusFilter = event.target.value;
    render();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeModal();
});

document.body.addEventListener("keydown", (event) => {
  const card = event.target.closest("[data-ticket-card]");
  if (card && ["Enter", " "].includes(event.key)) {
    event.preventDefault();
    openTicket(card.dataset.ticketCard);
  }
});

document.querySelector("#today-label").textContent = new Intl.DateTimeFormat("es-GT", { weekday: "short", day: "numeric", month: "short" }).format(new Date());
if (typeof ServiceDeskAuth === "undefined") {
  render();
} else {
  ServiceDeskAuth.start({
    onSession: (session, event) => {
      if (event === "PASSWORD_RECOVERY" && session) {
        state.authSession = session;
        renderAuthScreen("update");
      } else if (session) activateServiceDesk(session);
      else if (event === "SIGNED_OUT" || event === "INITIAL_SESSION") {
        state.authSession = null;
        state.dataLoaded = false;
        state.dataUserId = null;
        state.tickets = [];
        CATALOG.splice(DEFAULT_CATALOG.length);
        renderAuthScreen("login");
      }
    },
  }).catch((error) => renderAuthScreen("login", error.message, true));
}
